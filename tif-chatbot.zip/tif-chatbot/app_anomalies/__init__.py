# /app_anomalies/__init__.py
from .routes import app_anomalies_bp

# Expose the blueprint
__all__ = ['app_anomalies_bp']