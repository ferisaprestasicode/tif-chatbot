# # /auth/__init__.py
# from .routes import chat_gen_bp

# # Expose the blueprint so it can be easily imported elsewhere in the app
# __all__ = ['chat_gen_bp']